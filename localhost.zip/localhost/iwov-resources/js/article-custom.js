// ARTICLE LISTING

var mediaWidth = window.matchMedia("(max-width: 767px)");
//let pathName = window.location.pathname?.split("/business")[0];
let pathName = window.location.pathname?.split("/")[0];
//pathName=pathName+"/revamp";
let totalCount = 0;
let currentCount = 0;

function addRevamptoLinks() {
	$("a").each(function () {
    let url = $(this).attr("href");
    const { hostname } = window.location;
    const urlList = ["www.uob.com.sg", "uob.com.sg"];
    const httpRegex = /^(http|https)/;
    const uobRegex = /^(http|https):\/\/(www.)?(uob.com.sg)/;
    const iSHrefLinkSameHost = (httpRegex.test(url) && uobRegex.test(url)) || !httpRegex.test(url);
    //const isNoRevamp = !url?.includes("/revamp");

    if (url?.includes("/business") && url?.includes(".page") && urlList?.includes(hostname) && iSHrefLinkSameHost ) {
			// Check for /sites and remove
			if (url?.includes("/sites")) {
				url = url?.replace("/sites", "");
			}
     // url = url?.replace("/business", "/revamp/business");
      $(this).attr("href", url);
    }
  });
}

function filterData(moreData, showButton){		
	var industry="";
	var topics="";
	var types="";
	var max = 50 + moreData; 
	var sort = "asc";
	
	
	if(mediaWidth.matches){
		
		$(".card.industriesFilter .wrapper .card-body .filter-item").each(function(i, ob) {
			if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") != "all-industries") {
				industry += $(this).attr("data-value")+",";
			}
			else if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "all-industries") {
				industry = "*";
			}			
		});
		
		$(".card.topicsFilter .wrapper .card-body .filter-item").each(function(i, ob) {
			if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") != "all-topics") {
				topics += $(this).attr("data-value")+",";
			}
			else if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "all-topics") {
				topics = "*";
			}
		});
		
		$(".card.typesFilter .wrapper .card-body .filter-item").each(function(i, ob) {
			if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") != "all-article-types") {
				types += $(this).attr("data-value")+",";
			}
			else if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "all-article-types") {
				types = "*";
			}
		});		
	}
	else{
		/* get values of selected industry  */
		$(".sme-hub-dropdown.industriesFilter .dropdown-menu .dropdown-item").each(function(i, ob) {
			console.log($(this).attr("data-state"));
			
			if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") != "all-industries") {
				console.log($(this).attr("data-value"));
				industry += $(this).attr("data-value")+",";
			}
			else if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "all-industries") {
				industry = "*";
			}
			
		});
		
		/* get values of selected topics  */
		$(".sme-hub-dropdown.topicsFilter .dropdown-menu .dropdown-item").each(function(i, ob) {
			console.log($(this).attr("data-state"));
			
			if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") != "all-topics") {
				console.log($(this).attr("data-value"));
				topics += $(this).attr("data-value")+",";
			}
			else if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "all-topics") {
				topics = "*";
			}
			
		});
		
		/* get values of selected types  */
		$(".sme-hub-dropdown.typesFilter .dropdown-menu .dropdown-item").each(function(i, ob) {
			console.log($(this).attr("data-state"));
			
			if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") != "all-article-types") {
				console.log($(this).attr("data-value"));
				types += $(this).attr("data-value")+",";
			}
			else if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "all-article-types") {
				types = "*";
			}
			
		});
	
	}
	
	
	industry = industry.replace(/,(?=\s*$)/, '');
	console.log("final industry"+industry);
	var postData = "MaximumNumberOfBlocks="+max+"&industry="+industry+"&topics="+topics+"&types="+types;
	let ajaxArticleUrl = ajax_articl_url?.includes(pathName) ? ajax_articl_url : `${pathName}${ajax_articl_url}`;
	
	$.ajax({
		type: "POST",
		url: ajaxArticleUrl,
		data : postData,
		dataType:"json",
		beforeSend:function(){
			$('.sme-hub-container .no-results').hide();
			$('.loading-graphic').show();
		},
		complete:function(){
			$('.loading-graphic').hide();
		},
		success:function(data){
			
			var responseJson = data;
			responseJson = responseJson.data.Result.Result.assets.document;
			totalCount = data.data.Result.Result.assets.total;
			currentCount = responseJson?.length || currentCount;
			
			console.log("responseJson "+JSON.stringify(responseJson));
			
			var html = "";
			
			if(!responseJson){
				$('.loading-graphic').hide();
				$('.sme-hub-container .no-results').show();
			}
			else {
				$('.sme-hub-container .no-results').hide();
				if (!responseJson.length){
					var rootPath = responseJson.content.Root.information;
					var articleURL = rootPath["article-url"].replace("/sites","");
					
					html += '<article class="col-md-4"><a class="img-link" href="'+ articleURL +'"><img src="'+ rootPath["related-image"] +'" class="thumbnail" alt=""></img>';							
					if(rootPath["assets-type"] === "videos"){								
						html += '<div class="btn-overlay"><button class="btn-default-primary border-0" data-lity="" href="'+ rootPath["video-path"] +'"><img src="/assets/web-resources/business/images/Icons/media-play.svg" alt="Watch Now"> Watch now</img></button></div>';
					}						
					html += '</a><div class="wrapper"><h4 class="uob-h4"><a href="'+ articleURL +'" class="link-hover-effect">'+ rootPath.title +'</a></h4><p class="subtitle post-meta">'+ new Intl.DateTimeFormat('en-GB', { dateStyle: 'medium' }).format(new Date(rootPath.date)) +' &#8226; '+ rootPath["read-time"] +'</p></div></article>';
					
				}
				else {
					var j = 12;
					if(!showButton){
						j = responseJson.length;
					}
					
					for (i = 0; i < responseJson.length && i < j ;i++) {					
						var rootPath = responseJson[i].content.Root.information;
						var articleURL = rootPath["article-url"].replace("/sites","");
						html += '<article class="col-md-4"><a class="img-link" href="'+ articleURL +'"><img src="'+ rootPath["related-image"] +'" class="thumbnail" alt=""></img>';
						if(rootPath["assets-type"] === "videos"){								
							html += '<div class="btn-overlay"><button class="btn-default-primary border-0" data-lity="" href="'+ rootPath["video-path"] +'"><img src="/assets/web-resources/business/images/Icons/media-play.svg" alt="Watch Now"> Watch now</img></button></div>';
						}
						html += '</a><div class="wrapper"><h4 class="uob-h4"><a href="'+ articleURL +'" class="link-hover-effect">'+ rootPath.title +'</a></h4><p class="subtitle post-meta">'+ new Intl.DateTimeFormat('en-GB', { dateStyle: 'medium' }).format(new Date(rootPath.date)) +' &#8226; '+ rootPath["read-time"] +'</p></div></article>';
					}
				}
			}
			
			$(".sme-hub-container .row.infinite-load").html(html);
			setTimeout(addRevamptoLinks, 1000);
			if(responseJson)
            {
              if (showButton && responseJson.length > 12){
                  $('.show-more-load').show();
              }
            }
		},
		error:function(){
			console.log("error"+error);
		}      
	});

}



// THEMATICS LISTING

function filterThematicsData(moreData, showButton){		
	var industry="";
	var topics= document.getElementById('topicValue').getAttribute('data-value');
	console.log("topics"+topics);
	var types="";
	var tags="";
	var max = 50 + moreData; 
	var sort = "asc";
	
	if(mediaWidth.matches){
		
		$(".card.industriesFilter .wrapper .card-body .filter-item").each(function(i, ob) {
			if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") != "all-industries") {
				industry += $(this).attr("data-value")+",";
			}
			else if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "all-industries") {
				industry = "*";
			}			
		});
		$(".card.typesFilter .wrapper .card-body .filter-item").each(function(i, ob) {
			if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") != "all-article-types") {
				types += $(this).attr("data-value")+",";
			}
			else if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "all-article-types") {
				types = "*";
			}
		});
		$(".card.tagsFilter .wrapper .card-body .filter-item").each(function(i, ob) {
			if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") != "all-article-tags") {
				var splitArray=$(this).attr("data-value").split("|")[0];
                console.log(splitArray);
				tags += splitArray +",";
			}
			else if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "all-article-tags") {
				tags = "*";
			}
		});
	}
	else{
		/* get values of selected industry  */
		$(".sme-hub-dropdown.industriesFilter .dropdown-menu .dropdown-item").each(function(i, ob) {
			console.log($(this).attr("data-state"));
			
			if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") != "all-industries") {
				console.log($(this).attr("data-value"));
				industry += $(this).attr("data-value")+",";
			}
			else if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "all-industries") {
				industry = "*";
			}
		});
		
		$(".sme-hub-dropdown.typesFilter .dropdown-menu .dropdown-item").each(function(i, ob) {
			console.log($(this).attr("data-state"));
			
			if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") != "all-article-types") {
				console.log($(this).attr("data-value"));
				types += $(this).attr("data-value")+",";
			}
			else if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "all-article-types") {
				types = "*";
			}
			
		});
		
		$(".sme-hub-dropdown.tagsFilter .dropdown-menu .dropdown-item").each(function(i, ob) {
			console.log($(this).attr("data-state"));
			
			if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") != "all-article-tags") {				
                var splitArray=$(this).attr("data-value").split("|")[0];
                console.log(splitArray);
				tags += splitArray +",";
			}
			else if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "all-article-tags") {
				tags = "*";
			}
			
		});
		
	}
	industry = industry.replace(/,(?=\s*$)/, '');
	console.log("final industry"+industry);
//	var postData = "MaximumNumberOfBlocks="+max+"&industry="+industry+"&topics=*&types=*";
    var postData = "MaximumNumberOfBlocks="+max+"&industry="+industry+"&topics="+topics+"&types="+types+"&tags="+tags;
	let ajaxThematicUrl = ajax_thematic_url?.includes(pathName) ? ajax_thematic_url : `${pathName}${ajax_thematic_url}`;

	
	$.ajax({
		type: "POST",
		url: ajaxThematicUrl,
		data : postData,
		dataType:"json",
		beforeSend:function(){
			$('.sme-hub-container .no-results').hide();
			$('.loading-graphic').show();
		},
		complete:function(){
			$('.loading-graphic').hide();
		},
		success:function(data){
			
			var responseJson = data;
			responseJson = responseJson.data.Result.Result.assets.document;
			totalCount = data.data.Result.Result.assets.total;
			currentCount = responseJson?.length || currentCount;
			
			console.log("responseJson "+JSON.stringify(responseJson));
			
			var html = "";
			
			if(!responseJson){
				$('.loading-graphic').hide();
				$('.sme-hub-container .no-results').show();
			}
			else {
				$('.sme-hub-container .no-results').hide();
				if (!responseJson.length){
					var rootPath = responseJson.content.Root.information;
            		var articleURL = rootPath["article-url"].replace("/sites","");
					var shortDescription = '';
					if (rootPath["short-description"]) {
						shortDescription = rootPath["short-description"];
					}
					
					html += '<article class="col-12 offset-lg-1 col-lg-10"><a class="img-link" href="'+ articleURL +'"><img src="'+ rootPath["related-image"] +'" class="thumbnail" alt=""></img>';						
					if(rootPath["assets-type"] === "videos"){								
						html += '<div class="btn-overlay"><button class="btn-default-primary border-0" data-lity="" href="'+ rootPath["video-path"] +'"><img src="/assets/web-resources/business/images/Icons/media-play.svg" alt="Watch Now"> Watch now</img></button></div>';
					}
					html += '</a><div class="wrapper"><h4 class="uob-h4"><a href="'+ articleURL +'" class="link-hover-effect">'+ rootPath.title +'</a></h4><p class="excerpts">'+ shortDescription +'</p><p class="subtitle post-meta">'+ new Intl.DateTimeFormat('en-GB', { dateStyle: 'medium' }).format(new Date(rootPath.date)) +' &#8226; '+ rootPath["read-time"] +'</p></div></article>';
					
				}
				else {
					var j = 6;
					if(!showButton){
						j = responseJson.length;
					}
					
					for (i = 0; i < responseJson.length && i < j ;i++) {					
						var rootPath = responseJson[i].content.Root.information;
                        var articleURL = rootPath["article-url"].replace("/sites","");
						var shortDescription = '';
						if (rootPath["short-description"]) {
							shortDescription = rootPath["short-description"];
						}
						
						html += '<article class="col-12 offset-lg-1 col-lg-10"><a class="img-link" href="'+ articleURL +'"><img src="'+ rootPath["related-image"] +'" class="thumbnail" alt=""></img>';						
						if(rootPath["assets-type"] === "videos"){								
							html += '<div class="btn-overlay"><button class="btn-default-primary border-0" data-lity="" href="'+ rootPath["video-path"] +'"><img src="/assets/web-resources/business/images/Icons/media-play.svg" alt="Watch Now"> Watch now</img></button></div>';
						}						
						html += '</a><div class="wrapper"><h4 class="uob-h4"><a href="'+ articleURL +'" class="link-hover-effect">'+ rootPath.title +'</a></h4><p class="excerpts">'+ shortDescription +'</p><p class="subtitle post-meta">'+ new Intl.DateTimeFormat('en-GB', { dateStyle: 'medium' }).format(new Date(rootPath.date)) +' &#8226; '+ rootPath["read-time"] +'</p></div></article>';
					}
				}
			}
			
			$(".sme-hub-container .row.infinite-load").html(html);
			setTimeout(addRevamptoLinks, 1000);
			if(responseJson)
            {
              if (showButton && responseJson.length > 6){
                  $('.show-more-load').show();
              }
            }
		},
		error:function(){
			console.log("error"+error);
		}      
	});

}



//EVENTS LISTING

function filterEventsData(moreData, showButton){		
	var industry="";
	var types="";
	var max = 50 + moreData;
	var sort = "asc";
	
	var curr = new Date();
	// var startDate = curr.toISOString().slice(0,10);
	// var endDate = curr.toISOString().slice(0,10);
	var startDate = new Date();
	var endDate = new Date();
	// alert("272-startDate[" + startDate + "]");
	var dateFlag = false;
	
	if(mediaWidth.matches){
		
		$(".card.industriesFilter .wrapper .card-body .filter-item").each(function(i, ob) {
			if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") != "all-industries") {
				industry += $(this).attr("data-value")+",";
			}
			else if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "all-industries") {
				industry = "*";
			}			
		});
				
		$(".card.typesFilter .wrapper .card-body .filter-item").each(function(i, ob) {
			if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") != "all-event-types") {
				types += $(this).attr("data-value")+",";
			}
			else if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "all-event-types") {
				types = "*";
			}
		});

		$(".card.dateFilter .wrapper .card-body .filter-item").each(function(i, ob) {
			// if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "this-week") {
				// startDate = new Date(curr.setDate(curr.getDate() - curr.getDay())).toISOString().slice(0,10);
				// endDate = new Date(curr.setDate(curr.getDate() - curr.getDay()+6)).toISOString().slice(0,10);
				// sort = "asc";
			// }
			// if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "this-month") {
				// sort = "asc";
				// //startDate = "*";
				// //endDate = "*";
			// }
			// if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "past-events") {
				// startDate = "*";
				// //endDate = "*";
				// dateFlag = true;
				// sort = "desc";
			// }			
			// if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "all-time") {
				// //startDate = "*";
				// //endDate = "*";
				// dateFlag = false;
				// sort = "asc";
			// }
			if ($(this).attr("data-state") === "checked" && (($(this).attr("data-value") === "upcoming") || $(this).attr("data-value") === "sắpdiễnra")) {
				startDate = new Date(curr.toISOString().slice(0,10));
				endDate = null;
				max = "100";
				dateFlag = true;
				sort = "asc";
			}
			
			if ($(this).attr("data-state") === "checked" && (($(this).attr("data-value") === "today") || $(this).attr("data-value") === "hômnay")) {
				startDate = new Date(curr.toISOString().slice(0,10));
				endDate = new Date(curr.toISOString().slice(0,10));
				max = "100";
				dateFlag = true;
				sort = "asc";
			}
			if ($(this).attr("data-state") === "checked" && (($(this).attr("data-value") === "thisweek")|| $(this).attr("data-value") === "trongtuần")) {
				startDate = new Date(curr.toISOString().slice(0,10));
				endDate = new Date(new Date(curr.setDate(curr.getDate() - curr.getDay()+6)).toISOString().slice(0,10));
				max = "100";
				dateFlag = true;
				sort = "asc";
			}
			if ($(this).attr("data-state") === "checked" && (($(this).attr("data-value") === "thismonth")|| $(this).attr("data-value") === "trongtháng")) {
				startDate = new Date(curr.toISOString().slice(0,10));
				endDate = new Date(new Date(curr.getFullYear(), curr.getMonth() + 1, 1).toISOString().slice(0,10));
				max = "100";
				dateFlag = true;
				sort = "asc";
			}
			if ($(this).attr("data-state") === "checked" && (($(this).attr("data-value") === "pastevents")|| $(this).attr("data-value") === "sựkiệnđãdiễnra")) {
				startDate = null;
				endDate = new Date(curr.toISOString().slice(0,10));
				max = "100";
				dateFlag = true;
				sort = "desc";
			}
		});
		
	}
	else{
		/* get values of selected industry  */
		$(".sme-hub-dropdown.industriesFilter .dropdown-menu .dropdown-item").each(function(i, ob) {
			console.log($(this).attr("data-state"));
			
			if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") != "all-industries") {
				console.log($(this).attr("data-value"));
				industry += $(this).attr("data-value")+",";
			}
			else if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "all-industries") {
				industry = "*";
			}			
		});
		
		/* get values of selected types  */
		$(".sme-hub-dropdown.typesFilter .dropdown-menu .dropdown-item").each(function(i, ob) {
			console.log($(this).attr("data-state"));
			
			if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") != "all-event-types") {
				console.log($(this).attr("data-value"));
				types += $(this).attr("data-value")+",";
			}
			else if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "all-event-types") {
				types = "*";
			}			
		});
		
		$(".sme-hub-dropdown.dateFilter .dropdown-menu .dropdown-item").each(function(i, ob) {
			console.log($(this).attr("data-state"));
			
			if ($(this).attr("data-state") === "checked" && (($(this).attr("data-value") === "upcoming") || $(this).attr("data-value") === "sắpdiễnra")) {
				console.log("===============inside upcoming=======================");
				startDate = new Date(curr.toISOString().slice(0,10));
				console.log("startDate :: "+startDate.toISOString().slice(0,10));
				console.log("startDate.getTime() :: "+startDate.getTime());
				endDate = null;
				max = "100";
				dateFlag = true;
				sort = "asc";
			}
			
			if ($(this).attr("data-state") === "checked" && (($(this).attr("data-value") === "today") || $(this).attr("data-value") === "hômnay")) {
				console.log("===============inside today===============");
				//startDate = new Date(new Date(curr.setDate(curr.getDate() - curr.getDay())).toISOString().slice(0,10));
				startDate = new Date(curr.toISOString().slice(0,10));
				console.log("startDate :: "+startDate);
				//endDate = new Date(new Date(new Date(curr.setDate(curr.getDate()+1)).toISOString().slice(0,10)).setHours(0));
				//endDate = new Date(curr.setDate(curr.getDate()+7)).toISOString().slice(0,10);
				endDate = new Date(curr.toISOString().slice(0,10));
				console.log("endDate :: "+endDate);
				// alert("this-week-startDate[" + startDate + "]");
				// alert("this-week-endDate[" + endDate + "]");
				max = "100";
				dateFlag = true;
				sort = "asc";
			}
			if ($(this).attr("data-state") === "checked" && (($(this).attr("data-value") === "thisweek")|| $(this).attr("data-value") === "trongtuần")) {
				console.log("===============inside this week===============");
				//startDate = new Date(new Date(curr.setDate(curr.getDate() - curr.getDay())).toISOString().slice(0,10));
				startDate = new Date(curr.toISOString().slice(0,10));
				console.log("startDate :: "+startDate);
				endDate = new Date(new Date(curr.setDate(curr.getDate() - curr.getDay()+6)).toISOString().slice(0,10));
				//endDate = new Date(curr.setDate(curr.getDate()+7)).toISOString().slice(0,10);
				console.log("endDate :: "+endDate);
				// alert("this-week-startDate[" + startDate + "]");
				// alert("this-week-endDate[" + endDate + "]");
				max = "100";
				dateFlag = true;
				sort = "asc";
			}
			if ($(this).attr("data-state") === "checked" && (($(this).attr("data-value") === "thismonth")|| $(this).attr("data-value") === "trongtháng"))  {
				console.log("===============inside this month===============");
				// startDate = new Date(new Date(curr.getFullYear(), curr.getMonth(), 2).toISOString().slice(0,10));
				startDate = new Date(curr.toISOString().slice(0,10));
				console.log("startDate :: "+startDate);
				endDate = new Date(new Date(curr.getFullYear(), curr.getMonth() + 1, 1).toISOString().slice(0,10));
				console.log("endDate :: "+endDate);
				// alert("this-month-startDate[" + startDate + "]");
				// alert("this-month-endDate[" + endDate + "]");
				max = "100";
				dateFlag = true;
				sort = "asc";
			}
			if ($(this).attr("data-state") === "checked" && (($(this).attr("data-value") === "pastevents")|| $(this).attr("data-value") === "sựkiệnđãdiễnra")) {
				startDate = null;
				endDate = new Date(curr.toISOString().slice(0,10));
				console.log("endDate :: "+endDate);
				// alert("past-events-startDate[" + startDate + "]");
				// alert("past-events-endDate[" + endDate + "]");
				max = "100";
				dateFlag = true;
				sort = "desc";
			}			
			// if ($(this).attr("data-state") === "checked" && $(this).attr("data-value") === "all-time") {
				// startDate = null;
				// endDate = null;
				// dateFlag = false;
				// sort = "asc";
			// }
		});
	}
	industry = industry.replace(/,(?=\s*$)/, '');
	console.log("final industry :: "+industry);
	var postData = "MaximumNumberOfBlocks="+max+"&industry="+industry+"&types="+types;
	let ajaxEventsUrl = ajax_events_url?.includes(pathName) ? ajax_events_url : `${pathName}${ajax_events_url}`;
	
	$.ajax({
		type: "POST",
		url: ajaxEventsUrl,
		data : postData,
		dataType:"json",
		beforeSend:function(){
			$('.sme-hub-container .no-results').hide();
			$('.loading-skeleton').css('display','flex');
		},
		complete:function(){
			$('.loading-skeleton').css('display','none');
		},
		success:function(data){
			
			var responseJson = data;
			if (responseJson.data.Result.Result.assets.total === 0) {
				responseJson = [];
			} else if (responseJson.data.Result.Result.assets.total > 1) {
				responseJson = responseJson.data.Result.Result.assets.document.map(item => item.content.Root.information);
			} else {
				responseJson = [responseJson.data.Result.Result.assets.document.content.Root.information];
			}
			totalCount = data.data.Result.Result.assets.total;
			currentCount = responseJson?.length || currentCount;
			// responseJson = data.data.Result.Result.assets.document;
          
			//console.log("responseJson "+JSON.stringify(responseJson));
			
			if (dateFlag && responseJson) {
				let flattenedResponseJson = [];
				responseJson.forEach(element => {
					var sDate = element["date-time"];

					if (Array.isArray(sDate)) {
						sDate.forEach(dateValue => {
							let tempElement = {...element};

							tempElement["date-time"] = dateValue;
							flattenedResponseJson.push(tempElement);
						});
					} else {
						flattenedResponseJson.push(element);
					}
					
				});
				//console.log("flattenedResponseJson :: "+JSON.stringify(flattenedResponseJson));
				responseJson = flattenedResponseJson.filter(function(elem) {
					console.log( "===========================================");
					var eventDate = new Date(elem["date-time"].date);
					//console.log( "JSON element eventDate :: "+eventDate.toISOString().slice(0,10));
					var expiryDate = new Date(elem["end-date"]);
					//console.log( "JSON element expiryDate :: "+expiryDate.toISOString().slice(0,10));
					var rFlag = false;
					if (startDate != null && endDate != null) {
						console.log( "startDate :: "+startDate.toISOString().slice(0,10));
						console.log( "eventDate :: "+eventDate.toISOString().slice(0,10));
						console.log( "endDate :: "+endDate.toISOString().slice(0,10));
						console.log( "expiryDate :: "+expiryDate.toISOString().slice(0,10));
						// if (startDate.getTime() <= eventDate.getTime() && eventDate.getTime() <= endDate.getTime()) {
							// rFlag = true;
						// } else if (startDate.getTime() <= expiryDate.getTime() && expiryDate.getTime() <= endDate.getTime() && expiryDate.getTime() >= eventDate.getTime()) {
							// rFlag = true;
						// } else if (eventDate.getTime() < startDate.getTime() && expiryDate.getTime() > endDate.getTime()) {
							// rFlag = true;
						// }
						
						if (startDate.getTime() <= eventDate.getTime() && eventDate.getTime() <= endDate.getTime()
							&& startDate.getTime() <= expiryDate.getTime() && expiryDate.getTime() >= eventDate.getTime()) {
							console.log("Current Event added");
							 rFlag = true;
						}
					}
					if (startDate == null && endDate != null) {
						//console.log( "startDate :: "+startDate.toISOString().slice(0,10));
						console.log( "eventDate :: "+eventDate.toISOString());
						console.log( "endDate :: "+endDate.toISOString());
						console.log( "expiryDate :: "+expiryDate.toISOString());
						
						//if (eventDate.getTime() < endDate.getTime() && expiryDate.getTime() < endDate.getTime()) {
						if (eventDate.getTime() < endDate.getTime()) {
							console.log("Old Event added");
							rFlag = true;
						}
					}
					if (startDate != null && endDate == null) {
							console.log( "startDate :: "+startDate.toISOString().slice(0,10));
							console.log( "eventDate :: "+eventDate.toISOString().slice(0,10));
							console.log( "expiryDate :: "+expiryDate.toISOString().slice(0,10));
						if (expiryDate.getTime() >= startDate.getTime() && eventDate.getTime() >= startDate.getTime()) {
							console.log("Upcoming Event added");
							rFlag = true;
						}
					}
					return rFlag;
				});
				
				//console.log("responseJson :: "+JSON.stringify(responseJson));
				if(!responseJson.length){
					$('.loading-skeleton').css('display','none');
					$('.sme-hub-container .infinite-load').hide();
					$('.sme-hub-container .no-results').show();
					return;
				}
			}
			
			var html = "";
			
			function asc_sort(a, b) {
				return new Date(a["date-time"].date).getTime() - new Date(b["date-time"].date).getTime();
			}
			function desc_sort(a, b) {
				return new Date(b["date-time"].date).getTime() - new Date(a["date-time"].date).getTime();
			}
			
			if(sort == "desc"){
				responseJson.sort(desc_sort);
			}
			else{
				responseJson.sort(asc_sort);
			}
			//console.log("Sorted responseJson :: "+JSON.stringify(responseJson));
			if(!responseJson.length){
				$('.loading-skeleton').css('display','none');
				$('.sme-hub-container .no-results').show();
			}
			else {
				$('.sme-hub-container .no-results').hide();
				$('.sme-hub-container .infinite-load').show();
				if (!responseJson.length){
					var rootPath = responseJson;
					var eventURL = rootPath["event-url"].replace("/sites","");
					var date="", time="", moreDates="";
					jQuery(rootPath["date-time"]).each(function(k, item){
						if(k===0)
						date = item.date, time = item.time;
						if(k >= 1)
							moreDates = "+ "+k+" more events";
						console.log(item.date + ' ' + item.time);
					});
					let dateTime = new Intl.DateTimeFormat('en-GB', { dateStyle: 'medium' }).format(new Date(date)) + (time ? `, ${time}` : time);
					console.log( "dateTime 1 :: "+dateTime);
					
					html += '<article class="col-12 offset-lg-1 col-lg-10"><a class="img-link" href="'+ eventURL +'"><img src="'+ rootPath["related-image"] +'" class="thumbnail" alt=""></img>';						
					html += '</a><div class="wrapper"><h4 class="uob-h4"><a href="'+ eventURL +'" class="link-hover-effect">'+ rootPath.title +'</a></h4><p class="events-meta-date"><img src="/assets/web-resources/business/images/Icons/icons-calendar-gray.svg" alt="Placeholder"></img>'+ dateTime +'</p><p class="events-meta-location"><img src="/assets/web-resources/business/images/Icons/icon-location-gray.svg" alt="Placeholder"></img>'+ rootPath["location"] +'</p></div></article>';
					
					console.log("responseJson.length :: "+responseJson.length);
				}
				else {
					var j = 6;
					if(!showButton){
						j = responseJson.length;
					}
					
					for (i = 0; i < responseJson.length && i < j ;i++) {					
						var rootPath = responseJson[i];
						var eventURL = rootPath["event-url"].replace("/sites","");
						var date="", time="", moreDates="";
						jQuery(rootPath["date-time"]).each(function(k, item){
							if(k===0)
							date = item.date, time = item.time;
							if(k >= 1)
								moreDates = "+ "+k+" more events";
							//console.log("DATE & TIME :: "+item.date + ' ' + item.time);
						});
						let dateTime = new Intl.DateTimeFormat('en-GB', { dateStyle: 'medium' }).format(new Date(date)) + (time ? `, ${time}` : time);
						//console.log( "dateTime for display :: "+dateTime);
						html += '<article class="col-12 offset-lg-1 col-lg-10"><a class="img-link" href="'+ eventURL +'"><img src="'+ rootPath["related-image"] +'" class="thumbnail" alt=""></img>';						
						html += '</a><div class="wrapper"><h4 class="uob-h4"><a href="'+ eventURL +'" class="link-hover-effect">'+ rootPath.title +'</a></h4><p class="events-meta-date"><img src="/assets/web-resources/business/images/Icons/icons-calendar-gray.svg" alt="Placeholder"></img>'+ dateTime +'</p><p class="events-meta-location"><img src="/assets/web-resources/business/images/Icons/icon-location-gray.svg" alt="Placeholder"></img>'+ rootPath["location"] +'</p></div></article>';			
					}
				}
			}
			
			$(".sme-hub-container .row.infinite-load").html(html);
			setTimeout(addRevamptoLinks, 1000);
			if(responseJson)
			{
              if (showButton && responseJson.length > 6){
				  console.log("responseJson.length :: "+responseJson.length);
                  $('.show-more-load').show();
              }
			}
		},
		error:function(){
			console.log("error"+error);
		}      
	});

}

$(document).ready(function () {
filterEventsData(1, true);
});
